
Delevered: 

1)Structure of the framework – using RestAssured
2)Code to retrieve the API link from config file
3)Separate test case file
4) Test case report in HTML file

FrameWork: Hybrid Type

TestDataLocation:*\src\test\resources\Resources\Datasheet.xlsx. You can add multiple rows of data as per your requirements.

Config Properties File Location: *\src\test\resources\Resources\UserConfig.properties. URI can change from Properties File

Reporting Used: Extent Report

Report Location: *\TestReports

Logger Used: Log4j

Logg Location: Application.txt

Used 3 Utility Files under Ulility Folder

For Execution: Total 2 Test Cases created seperatedely. You need to run as TestNg.xml for Execution in Bulk. Else individual also you can execute on selecting the particular Test Cases. 
