package Utilities;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Utility3_ExcelReader 
{

	 public Object[][] gettest(String sn) 
	  {
		 FileInputStream fis=null;
		  Workbook book = null;
		  Sheet sheet;
		  try
		  {
			   fis= new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\Resources\\DataSheet.xlsx");
		  }
		  catch (Exception e) {
				System.out.println(e.getMessage());
		  }
		try{
			book = WorkbookFactory.create(fis);
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
	  }
			sheet=book.getSheet(sn);
		
		  
		  
		  Object[][] data=new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		  
		  for(int i=0;i<sheet.getLastRowNum();i++)
		  {
			 
			  for(int k=0;k<sheet.getRow(0).getLastCellNum();k++)
			  {
				  
				  data[i][k]=sheet.getRow(i+1).getCell(k).toString();
			  }
		  }

		return data;
		  
	  }
}
