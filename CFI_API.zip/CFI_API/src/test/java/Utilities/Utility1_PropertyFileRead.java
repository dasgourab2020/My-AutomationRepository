package Utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class Utility1_PropertyFileRead
{
	Properties prop;
	public Utility1_PropertyFileRead()
	{
	
	 prop=new Properties();
	FileInputStream fis;
	try {
		fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\Resources\\UserConfig.properties");
		prop.load(fis);
		
		
		
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
	}

	}
	
	public String url()
	
	{
		String URL=prop.getProperty("QAURL");
		return URL;
		
	}
public String TestReportName()
	
	{
		String TestReportName=prop.getProperty("TestReportName");
		return TestReportName;
		
	}
public String ReportName()

{
	String ReportName=prop.getProperty("ReportName");
	return ReportName;
	
}
public String ReportTitle()

{
	String ReportTitle=prop.getProperty("ReportTitle");
	return ReportTitle;
	
}
public String RegressionTester()

{
	String RegressionTester=prop.getProperty("RegressionTester");
	return RegressionTester;
	
}
	

}
