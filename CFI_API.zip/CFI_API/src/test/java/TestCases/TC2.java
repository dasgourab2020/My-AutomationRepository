/**
 * 
 */
package TestCases;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.Utility2_ExtendReport;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

/**
 * @author Gourab
 *
 */
public class TC2 extends BaseTest
{

	@Test (priority=1)
	public void TC2()
	{
     String endpoint="/employees";
		
		String responceURI=endpoint;
		
		try
		{
	
			Utility2_ExtendReport.extentTest=u2.extent.createTest("Scenerio 1: Verifications of Blank profile image of all Employee");
			
		  
		  Response response=httprequest.request(Method.GET, responceURI);	

		  
		  Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("API Response Status Code:  "+response.getStatusCode()).pass(mpass);
		  
		  JsonPath jsonpath=response.jsonPath();
		  
		  
		 List <String> status =(jsonpath.get("data.profile_image"));
		 for (String newstatus: status)
		 {
			
			 
			 
			 if(newstatus=="")
			 {
				Assert.assertEquals(true, true); 
			 }
			 else
			 {
				 Assert.assertEquals(true, false);
				 Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Verifications of Blank Profile Image of all Employee is failed as some profile has image").fail(mfail);
				 
			 }
					 
		 }
		 Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Verifications of Blank Profile Image of all Employee is passed as no profile has image in it.").pass(mpass); 		
		 log.info("****************************** End test case *****************************************");
		 }
		catch(Exception e)
		{
			log.info("****************************** End test case *****************************************");
			Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Internal Exception occured "+e.getMessage()).fail(mfail);
			
			
		} 
	}
	
	
}
