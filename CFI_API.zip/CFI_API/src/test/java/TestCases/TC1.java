package TestCases;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Utilities.Utility1_PropertyFileRead;
import Utilities.Utility2_ExtendReport;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class TC1 extends BaseTest
{
	
	@Test(dataProvider="EmployeeDetails", priority=2)
  public void getdetails(String slno, String Emp_ID, String EMP_Name)
  {
		
		int empid=Integer.parseInt(Emp_ID);
		try {
		SoftAssert asserts= new SoftAssert();
		
		Utility2_ExtendReport.extentTest=u2.extent.createTest("Scenerio 2:  Details Verifications of the Employee Name: "+EMP_Name);
		
		String endpoint="/employee/"+Emp_ID;
		
		String responceURI=endpoint;
		  
		  Response response1=httprequest.request(Method.GET, responceURI);	

		  
		  JsonPath jsonpath1=response1.jsonPath();
		  
		 
		  int id=jsonpath1.get("data.id");
		  String name =jsonpath1.get("data.employee_name");
		  String msg=jsonpath1.get("message");
		
	asserts.assertEquals(id, empid);
	asserts.assertEquals(name, EMP_Name);
	asserts.assertEquals(msg, "Successfully! Record has been fetched.");
		  
	  
	  
	 Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("API Response Status Code:  "+response1.getStatusCode()).pass(mpass);
	  
	  Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("For Employee Name: "+name+ " Verification message is successfully passed. Message: "+msg).pass(mpass);
	  
	
	  
	asserts.assertAll();
	 
	 log.info("****************************** End test case *****************************************");
	    
		}
		catch(Exception e)
		{
			log.info("****************************** End test case *****************************************");
			Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Internal Exception occured "+e.getMessage()).fail(mfail);
			
			
		}      
	 
	  
  }
	

}	




	
	