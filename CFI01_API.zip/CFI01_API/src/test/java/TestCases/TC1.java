package TestCases;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Utilities.Utility1_PropertyFileRead;
import Utilities.Utility2_ExtendReport;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC1 extends BaseTest
{
	
	@Test(dataProvider="CovidTest")
  public void getdetails(String date, String Covidcases, String recover, String Code, String month, String Country)
  {
		try {
		SoftAssert asserts= new SoftAssert();
		
		Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("COVID-19 API Data Verification of "+ Country+" for "+month);
		
		
	  String pre="status/";
	  String mid="?date=";
	  
	  String responceURI=pre+Code+mid+date;
	  
	  Response response=httprequest.request(Method.GET, responceURI);	

	  int statuscode=response.getStatusCode();
	  
	  JsonPath jsonpath=response.jsonPath();
	  
	  int cases=jsonpath.get("cases");
	  int recovered=jsonpath.get("recovered");
	 Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("API Response Status Code:  "+response.getStatusCode()).pass(mpass);
	  asserts.assertEquals(Integer.toString(cases), Covidcases, "Total Cases verification failed");
	  Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Total Covid cases in "+Country+" verified for the Month: "+date+ " and Total Cases: "+cases).pass(mpass);
	  asserts.assertEquals(Integer.toString(recovered), recover, "Total Recovered verification failed");
	
	  Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Total Covid Recovered cases in "+Country+" verified for the Month: "+date+ " and Total Recovered Cases: "+recovered).pass(mpass);
	 Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Total Responce Time (in Mili Seconds): "+response.getTimeIn(TimeUnit.MILLISECONDS)).pass(mpass);
	 asserts.assertAll();
	 
	 log.info("****************************** End test case *****************************************");
	    
		}
		catch(Exception e)
		{
			log.info("****************************** End test case *****************************************");
			Utility2_ExtendReport.childtest=Utility2_ExtendReport.extentTest.createNode("Internal Exception occured "+e.getMessage()).fail(mfail);
			
			
		}
	 
	  
  }
}	




	
	