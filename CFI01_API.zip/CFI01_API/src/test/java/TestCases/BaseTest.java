package TestCases;

import java.io.IOException;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import Utilities.Utility1_PropertyFileRead;
import Utilities.Utility2_ExtendReport;
import Utilities.Utility3_ExcelReader;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;





public class BaseTest 
{
	Logger log = Logger.getLogger(BaseTest.class);
	Utility1_PropertyFileRead u=new Utility1_PropertyFileRead();
	Utility3_ExcelReader u3= new Utility3_ExcelReader();
	Utility2_ExtendReport u2=new Utility2_ExtendReport();
	String logpassTest="<b>Test Method Passed</b>";
	Markup mpass=MarkupHelper.createLabel(logpassTest, ExtentColor.GREEN);
	String logfailTest="<b>Test Method Failed</b>";
	Markup mfail=MarkupHelper.createLabel(logfailTest, ExtentColor.RED);
	RequestSpecification httprequest;
	
	
	@BeforeSuite
	 public void reportlogger()
	 {
		 u2.newreport();
	 }
	 @AfterSuite
	   public void endreport()
	   {    
		   u2.endreport();
		   
	   }
	 
	 @BeforeMethod
	 public void invoke()
	 {
		 log.info("****************************** starting test case *****************************************");
		 Utility2_ExtendReport.extentTest=u2.extent.createTest("COVID-19 API Data Verification Test Country and Datewise");
		 RestAssured.baseURI=u.url();
		  httprequest=RestAssured.given();
	 }
	 
	 @AfterMethod
	 public void teardown(ITestResult result) throws IOException 	 
		{
			
			String methodName=result.getMethod().getMethodName();
			if(result.getStatus()==ITestResult.FAILURE)
			{
				String exceptionMessage=Arrays.toString(result.getThrowable().getStackTrace());
				
				
			
				Utility2_ExtendReport.extentTest.fail("<details><summary><b><font color=red>Exceptions Occured, Click to see details:"
							+"</font></b></summary>"+exceptionMessage.replaceAll(",", "<br>")+"</details>\n");
				
				
				
				String logTest="<b>Test Method "+methodName+"Failed</b>";
				Markup m=MarkupHelper.createLabel(logTest, ExtentColor.RED);
				Utility2_ExtendReport.extentTest.fail(logTest);
				Utility2_ExtendReport.extentTest.fail(m);
				 
			}
			else if(result.getStatus()==ITestResult.SUCCESS)
			{
				String logTest="<b>Test Method "+methodName+"Passed</b>";
				Markup m=MarkupHelper.createLabel(logTest, ExtentColor.GREEN);
				Utility2_ExtendReport.extentTest.pass(logTest);
				Utility2_ExtendReport.extentTest.pass(m);
			}
			else if(result.getStatus()==ITestResult.SKIP)
			{
				String logTest="<b>Test Method "+methodName+"Skipped</b>";
				Markup m=MarkupHelper.createLabel(logTest, ExtentColor.ORANGE);
				Utility2_ExtendReport.extentTest.skip(logTest);
				Utility2_ExtendReport.extentTest.skip(m);
			}
		}
	 @DataProvider
		public Object[][] CovidTest()
		
		{
			Object data[][]=u3.gettest("Datasheet");
			return data;
			
		}
     
}
