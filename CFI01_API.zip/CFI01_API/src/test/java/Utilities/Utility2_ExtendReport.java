package Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Utility2_ExtendReport 
{

	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest extentTest;
	public static ExtentTest parenttest;
	public static ExtentTest childtest;
	
	Utility1_PropertyFileRead u=new Utility1_PropertyFileRead();
	
	
	public void newreport()
	{
		String path=System.getProperty("user.dir")+"\\TestReports\\"+u.TestReportName()+".html";
		htmlReporter=new ExtentHtmlReporter(path);
		htmlReporter.config().setReportName(u.ReportName());
		htmlReporter.config().setDocumentTitle(u.ReportTitle());
		htmlReporter.config().getTimeStampFormat();
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setTheme(Theme.STANDARD);
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("Regression Tester", u.RegressionTester());
		
		extent.attachReporter(htmlReporter);
	
		
	}

	public void endreport()
	{
		extent.flush();
		
	}
}
