FrameWork: Hybrid

TestDataLocation:*\src\test\resources\Resources\Datasheet.xlsx

Config Properties File Location: *\src\test\resources\Resources\UserConfig.properties

Reporting Used: Extent Report

Report Location: *\TestReports

Logger Used: Log4j

Logg Location: Application.txt

Used 3 Utility Files under Ulility Folder

One Test Script created. It will Run for n- number of times with Different Sets of Data.
It Will verify for all Countries based on Country Code. Only User Needs to add data rowwise.
Reports will come for Each Row. Sample Report is there at Test Report Folder


For Execution: TestNg Used. You need to run as TestNg for Execution
URI can change from Properties File